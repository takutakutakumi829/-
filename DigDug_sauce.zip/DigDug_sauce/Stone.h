#pragma once
#include "Obj.h"
class Stone :
	public Obj
{
public:
	Stone(VECTOR2 chipOffSet);
	~Stone();

private:
	char KeyData[256];
	char KeyDataOld[256];

};

