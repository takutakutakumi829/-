#pragma once


//static GameTask *GetInstance(){		return s_Instance;	}



