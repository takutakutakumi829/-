#include "Stone.h"



Stone::Stone(VECTOR2 chipOffSet):Obj(KeyData,KeyDataOld, chipOffSet)
{
}


Stone::~Stone()
{
}
